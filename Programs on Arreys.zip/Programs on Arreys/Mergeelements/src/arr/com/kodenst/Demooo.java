package arr.com.kodenst;

import java.util.Scanner;

public class Demooo {
	public static void main(String[] args) {
Scanner scan=new Scanner(System.in);{
	System.out.println("enter the length of arr--1");
	int arr1[]=new int[scan.nextInt()];
	int arr2[]=new int[arr1.length];
	
	System.out.println("enter " +arr1.length+ " elements ");
	for(int i=0;i<=arr1.length-1;i++) {
		arr1[i]=scan.nextInt();
	}
	System.out.println("enter "+arr2.length+ " elements ");
	for(int i=0;i<=arr2.length-1;i++) {
		arr2[i]=scan.nextInt();
	}
	int arr3[]=new int[arr1.length+arr2.length];
	int i=0;
	for(int j=0;j<=arr1.length-1;j++) {
		arr3[i]=arr1[j];
		i++;
	}
	for(int j=0;j<=arr2.length-1;j++) {
		arr3[i]=arr2[j];
		i++;
	
}
	System.out.println("arr1==>");
	for(int j=0;j<=arr1.length-1;j++) {
		System.out.print(arr1[j]+ " ");
	}
	System.out.println();
	System.out.println("arr2==>");
	for(int j=0;j<=arr2.length-1;j++) {
		System.out.print(arr2[j]+ " ");
	}
	System.out.println();
	System.out.println("arr3==>");
	for(int j=0;j<=arr3.length-1;j++) {
		System.out.print(arr3[j]+ " ");
	}
}
}
}
