package jagg;

import java.util.Scanner;

public class DEMO7 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
	    Float[][]ply_height=new Float[3][];
	    ply_height[0]=new Float[3];
	    ply_height[1]=new Float[2];
	    ply_height[2]=new Float[4];
	    
	    for(int i=0;i<=ply_height.length-1;i++) {
	    	for(int j=0;j<=ply_height.length-1;j++) {
	    		System.out.println("Enter the game " +i+" player" +j+" ");
	    		ply_height[i][j]=scan.nextFloat();
	    	}
	    }
	    System.out.println(" Arreys contents are .....");
	    for(int i=0;i<=ply_height.length-1;i++) {
	    	for(int j=0;j<=ply_height[i].length-1;j++) {
	    		System.out.println(ply_height[i][j] + " ");
	    	}
	    	System.out.println();
	    }
	}

}
