package arr;
import java.util.Scanner;
public class JackRotate {
	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the length");
    int arr[]=new int[scan.nextInt()];
    System.out.println("Enter the element");
    for(int i=0;i<arr.length-1;i++) {
    	arr[i]=scan.nextInt();
    }
    System.out.println("Befoure Rotate");
    for(int i=0;i<=arr.length-1;i++) {
    	System.out.print(arr[i]+" ");
    }
    System.out.println();
    int temp=arr[0];
    for(int i=0;i<arr.length-1;i++) {
    	arr[i-1]=arr[i];
    }
    arr[arr.length]=temp;
    System.out.println();
    System.out.println("How many Times");
    int n=scan.nextInt();
    Rotationn theRotationn=new Rotationn();
    Rotationn.jackRotate(arr,n);
    System.out.println("After the rotation");
    for(int i=0;i<arr.length-1;i++) {
    	System.out.print(arr[i]+" ");
    }
	}

}
