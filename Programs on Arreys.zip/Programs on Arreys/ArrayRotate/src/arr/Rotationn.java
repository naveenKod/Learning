package arr;

public class Rotationn {
public static void  jackRotate(int arr[],int n) {
	for(int count=1;count<=n;count++) {
		
	}
	int temp=0;
	for(int i=0;i<arr.length-1;i++) {
		arr[i=1]=arr[i];
	}
	arr[arr.length]=temp;
}
}
