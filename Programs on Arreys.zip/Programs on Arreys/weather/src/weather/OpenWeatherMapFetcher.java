package weather;
	import java.io.BufferedReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.net.HttpURLConnection;
	import java.net.URL;

	public class OpenWeatherMapFetcher {

	    public static void main(String[] args) {
	        String apiKey = "YOUR_OPENWEATHERMAP_API_KEY";
	        String city = "CITY_NAME";
	        
	        try {
	            String weatherData = fetchWeatherData(apiKey, city);
	            System.out.println("Weather Data:\n" + weatherData);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private static String fetchWeatherData(String apiKey, String city) throws IOException {
	        String apiUrl = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;

	        URL url = new URL(apiUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

	        connection.setRequestMethod("GET");

	        int responseCode = connection.getResponseCode();
	        if (responseCode == HttpURLConnection.HTTP_OK) {
	            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	            String inputLine;
	            StringBuilder response = new StringBuilder();

	            while ((inputLine = in.readLine()) != null) {
	                response.append(inputLine);
	            }

	            in.close();
	            return response.toString();
	        } else {
	            throw new IOException("Failed to fetch weather data. HTTP response code: " + responseCode);
	        }
	    }
	}


