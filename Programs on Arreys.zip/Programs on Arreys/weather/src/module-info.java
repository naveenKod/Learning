/**
 * 
 */
/**
 * 
 */
module weather {
}