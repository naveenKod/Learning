package Arr.com.kodHW;

import java.util.Scanner;

public class DemoHW {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    System.out.println("enter the lngth of array");
    int arr1[]=new int[scan.nextInt()];
    int arr2[]=new int[arr1.length];
    
    for(int i=0;i<=arr1.length-1;i++) {
    	
    }
	}

}
