package lock;

import java.util.Scanner;

public class Student {
public static; main(String[] args) {
	Scanner scan=new Scanner( System.in);
	student s1=new student();
	student s2=new student();
	stuednt s3=new student();
	
	s1.rollnumber=1;
	s2.rollnumber=2;
	s3.rollnumber=3;
	
	s1.name="naveen";
	s2.name="navya";
	s3.name="bhavya";
	
	s1.age=23;
	s2.age=24;
	s3.age=23;
}
}
