package com.java;

import java.util.Scanner;

public class Demo2 {

	public static void main(String[] args) {
Scanner scan=new Scanner(System.in);
int[]arr=new int[3];
for(int i=0;i<=arr.length-1;i++) {
	System.out.println("enter the element");
	arr[i]=scan.nextInt();
}
System.out.println("arrets contents are......");
for(int i=0;i<=arr.length-1;i++) {
	System.out.println(arr[i]+" ");
}
	}

}
