package arr;
import java.util.Scanner;
public class MatrixMultiplay {
	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the row and cols");
    int row=scan.nextInt();
    int cols=scan.nextInt();
    int arr[][]=new int[row][cols];
    System.out.println("Enter"+(row*cols)+" array element");
    for(int i=0;i<=arr.length-1;i++) {
    	for(int j=0;j<=arr[i].length-1;j++) {
    		arr[i][j]=scan.nextInt();
    	}
    }
    System.out.println("Matrix....");
    for(int i=0;i<=arr.length-1;i++) {
    	for(int j=0;j<=arr[i].length-1;j++) {
    	System.out.print(arr[i][j]+" ");	
    	}
    	System.out.println();
	}
    System.out.println("=======================");
    for(int k=0;k<=2;k++) {
    	System.out.print(arr[0][k]+" ");
    }
    for(int k=1;k<=2;k--) {
    	System.out.print(arr[k][2]+" ");
    }

}
}