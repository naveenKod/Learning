package arr;

import java.util.Scanner;

public class Demo5 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
   String [][] Bank_custmers=new String[5][6];
   for(int i=0;i<=Bank_custmers.length-1;i++) {
	   for(int j=0;j<=Bank_custmers.length-1;j++) {
		   System.out.println(" Bank " + i + " custmer " + j + " :");
		   Bank_custmers[i][j]=scan.next();
	   }
   }
   System.out.println("arrey contents are....");
   System.out.println("--------------------");
   for(int i=0;i<=Bank_custmers.length-1;i++) {
	   for(int j=0;j<=Bank_custmers.length-1;j++)
	   {
		   
		   System.out.print(Bank_custmers[i][j]+" | ");
	   }
	   System.out.println();
   }System.out.println("-------------------------");
	}

}
