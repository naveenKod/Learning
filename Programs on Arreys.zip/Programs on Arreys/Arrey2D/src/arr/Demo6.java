package arr;

import java.util.Scanner;

public class Demo6 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    float [][] emp_height=new float[2][3];
    for(int i=0;i<=emp_height.length-1;i++) {
    	for(int j=0;j<=emp_height.length-1;j++) {
    		System.out.println(" Emp " + i + " emp " + j + "  :");
    		emp_height[i][j]=scan.nextFloat();
    	}
    }
    	System.out.println("Arreys are===>");
    	System.out.println("===========================================");
    	for(int i=0;i<=emp_height.length-1;i++) {
    		for(int j=0;j<=emp_height.length-1;j++) {
    			System.out.print(emp_height[i][j] + "  |  ");
    		}
    		System.out.println();
    	}
    	System.out.println("===========================================");
    	
    }
	}

