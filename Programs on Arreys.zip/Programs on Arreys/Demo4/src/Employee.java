import java.util.Scanner;

public class Employee {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int[]arr=new int[8];
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println("enter employee name");
			arr[i]=scan.nextInt();
		}
		System.out.println("arrets contents are......");
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]+" ");
		}
	}

}
