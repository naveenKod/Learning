package Alg.com.kod;

import java.util.Scanner;

public class ArrayRotate {
	public static void main(String[] args) {
	    Scanner scan=new Scanner(System.in);
	  System.out.println("Enter arr length");
	  int arr[]=new int[scan.nextInt()];
	  System.out.println("enter the array element");
	  for(int i=0;i<=arr.length-1;i++) {
		  arr[i]=scan.nextInt();
	  }
	  System.out.println("Arr Elements before rotate");
	  for(int i=0;i<=arr.length-1;i++) {
		  System.out.print(arr[i]+" ");
	  }
	  System.out.println();
	  
	int   temp=arr[0];
	for(int i=1;i<=arr.length-1;i++) {
		arr[i-1]=arr[i];
	}
	arr[arr.length-1]=temp;
	
	System.out.println();
	System.out.println("Enter how many times rotate");
	int n=scan.nextInt();
	Rotation theRotation=new Rotation();
	theRotation.arrayRotate(arr,n);
	
	System.out.println("Arr Elements After rotate");
	  for(int i=0;i<=arr.length-1;i++) {
		  System.out.print(arr[i]+" ");
	  
}
}
}