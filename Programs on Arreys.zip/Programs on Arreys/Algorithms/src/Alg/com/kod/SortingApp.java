package Alg.com.kod;

import java.util.Scanner;

public class SortingApp {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
  System.out.println("Enter arr length");
  int arr[]=new int[scan.nextInt()];
  System.out.println("Enter " +arr.length+ " Element");
  for(int i=0;i<=arr.length-1;i++) {
	  arr[i]=scan.nextInt();
  }
  System.out.println("Arr Ele Befour Sorting");
  for(int i=0;i<=arr.length-1;i++) {
	  System.out.println(arr[i]+" ");
  }
 
  BubbleSort sort=new BubbleSort();
  sort.BubbleSort(arr);
  System.out.println();

  System.out.println("Arr Ele After the Sorting");
  for(int i=0;i<=arr.length-1;i++) {
	  System.out.println(arr[i]+" ");
  }
	}

}
