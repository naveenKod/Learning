package Alg.com.kod;

import java.util.Scanner;

public class Binuary {

	public static void main(String[] args) {
    Scanner scan=new Scanner( System.in);
    System.out.println("Enter the length of array");
    int arr[]=new int[scan.nextInt()];
    System.out.println("eneter "+arr.length+" element");
    for(int i=0;i<=arr.length-1;i++) {
    	arr[i]=scan.nextInt();
    }
    System.out.println("Enter key to serch");
    int key=scan.nextInt();
    int low=0;
    int high=arr.length-1;
    while(low<=high) {
    	
    int mid=(low+high)/2;
    if(key==arr[mid]) {
    	System.out.println("Key found at "+mid);
    	return;
    }
    else if(key<arr[mid]) {
    	low=mid+1;
    }
    else {
    	high=mid-1;
    }
	}
    System.out.println("key not found");
	}

}


