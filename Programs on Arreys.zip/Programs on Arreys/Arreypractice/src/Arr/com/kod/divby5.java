package Arr.com.kod;

import java.util.Scanner;

public class divby5 {

	public static void main(String[] args) {
    Scanner scan=new Scanner( System.in);
      System.out.println("Enter the length of arrey");
      int arr[]=new int[scan.nextInt()];
    
    for(int i=0;i<=arr.length-1;i++) {
    	arr[i]=scan.nextInt(); 
    	
    	}
    	for(int i=0;i<=arr.length-1;i++) {
    		if(arr[i]%5==0)
    			System.out.println(arr[i]+" ");
    	}
    }
	}


