package Arr.com.kod;

import java.util.Scanner;

public class sum {

	public static void main(String[] args) {
    Scanner scan=new Scanner( System.in);
    System.out.println("Enter the length of array");
    int arr[]=new int[scan.nextInt()];
    for(int i=0;i<=arr.length-1;i++) {
    	arr[i]=scan.nextInt();
    }
    	int sum=0;
    	for(int i=0;i<=arr.length-1;i++) {
    		sum=sum +arr[i];
    		
    	}
    	System.out.println("sum oaf array"+sum);
    	
    }
	}


