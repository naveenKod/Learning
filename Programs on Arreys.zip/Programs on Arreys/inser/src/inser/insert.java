package inser;

public class insert {

}
