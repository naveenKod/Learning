package ArreY;

public class Demo {

	public static void main(String[] args) {
     int []arr=new int[5];
     arr[0]=22;
     arr[1]=23;
     arr[2]=24;
     arr[3]=20;
     arr[4]=22;
     System.out.print("arreys are-->");
     System.out.print(arr[0]+" | ");
     System.out.print(arr[1]+" | ");
     System.out.print(arr[2]+" | ");
     System.out.print(arr[3]+" | ");
     System.out.print(arr[4]+" | ");
	}

}
