package ArreY;

import java.util.Scanner;

public class Demo2 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    int []arr=new int [3];
    for(int i=0;i<=arr.length-1;i++) {
    	System.out.print("Enter the element");
    	arr[i]=scan.nextInt();
    }
    System.out.print("arreys are-->");
    for(int i=0;i<=arr.length-1;i++) {
    	System.out.print(arr[i]+" ");
    }
	}

}
