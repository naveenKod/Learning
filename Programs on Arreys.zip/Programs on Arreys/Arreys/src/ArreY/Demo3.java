package ArreY;

import java.util.Scanner;

public class Demo3 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    System.out.println("enter student mark");
    int mark[]=new int[5];
    for(int i=0;i<=mark.length-1;i++) {
    	mark[i]=scan.nextInt();
    }
    System.out.print("Students marks are-->");
    for(int i=0;i<=mark.length-1;i++) {
    	System.out.print(mark[i]+" | ");
    }
	}

}
