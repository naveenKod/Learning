package ArreY;

import java.util.Scanner;

public class Demo4 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    String emp[]=new String[8];
    for(int i=0;i<=emp.length-1;i++) {
    	System.out.print("Enter the emp name");
    	emp [i]=scan.next();
    }
    System.out.print("Emp Names -->");
    for(int i=0;i<=emp.length-1;i++) {
    	System.out.print(emp[i]+" | ");
    }
	}

}
