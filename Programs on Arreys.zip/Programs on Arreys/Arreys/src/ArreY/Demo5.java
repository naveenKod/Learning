package ArreY;

import java.util.Scanner;

public class Demo5 {

	public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
    float hei[]=new float[10];
    for(int i=0;i<=hei.length-1;i++) {
    	System.out.print("Enter the Height of Players");
    	hei[i]=scan.nextFloat();
    }
    System.out.print("Players Height are==>");
    for(int i=0;i<=hei.length-1;i++) {
    	System.out.print(hei[i]+" || "); 
    }
	}

}
