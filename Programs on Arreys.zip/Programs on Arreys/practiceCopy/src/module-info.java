/**
 * 
 */
/**
 * 
 */
module practiceCopy {
}