package sumarr.com.kpdnest;

import java.util.Scanner;

public class demoo {

	public static void main(String[] args) {
		Scanner scan=new Scanner( System.in);
		System.out.println("enter the length of array1");  
		        int[] array1 =new int[scan.nextInt()];
		        System.out.println("Enter the length of array2");
		        int[] array2 = new int [scan.nextInt()];
		        
		        if (array1.length != array2.length) {
		            System.out.println("Arrays must be of the same size.");
		            return;
		        }
		        int[] sumArray = new int[array1.length];
		    
		        for (int i = 0; i < array1.length; i++) {
		            sumArray[i] = array1[i] + array2[i];
		        }
		        
		      
		        System.out.print("Sum of the  elements: ");
		        for (int i = 0; i < sumArray.length; i++) {
		            System.out.print(sumArray[i] + " ");
		        }
		    }
		}

    
	


