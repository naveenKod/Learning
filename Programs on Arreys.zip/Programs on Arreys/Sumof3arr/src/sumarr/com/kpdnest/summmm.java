package sumarr.com.kpdnest;

import java.util.Scanner;

public class summmm {

	public static void main(String[] args) {
     Scanner scan=new Scanner (System.in);
     System.out.println("Enter the length of array");
     int arr1[]=new int[scan.nextInt()];
     int arr2[]=new int[arr1.length];
     
     System.out.println("Enter arr1 Elements");
     for(int i=0;i<=arr1.length-1;i++) {
    	 arr1[i]=scan.nextInt();
     }
     System.out.println("Enter arr2 Elements");
     for(int i=0;i<=arr2.length-1;i++) {
    	 arr2[i]=scan.nextInt();
     }
     System.out.println();
     int arr3[]=new int[arr1.length];
     for(int i=0;i<arr1.length-1;i++) {
    	 arr3[i]=arr1[i]+arr2[i];
     }
     System.out.println("arr1 contets are....");
     for(int i=0;i<=arr1.length-1;i++) {
    	 System.out.print(arr1[i]+" ");
     }
     System.out.println();
     System.out.println("arr2 contents are....");
     for(int i=0;i<=arr2.length-1;i++) {
    	 System.out.print(arr2[i]+" ");
	}
     System.out.println();
     System.out.println("SUM OF CONTENTS");
     for(int i=0;i<=arr3.length-1;i++) {
    	 System.out.print(arr3[i]+" ");
	}
}
}