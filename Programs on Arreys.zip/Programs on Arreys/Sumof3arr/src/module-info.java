/**
 * 
 */
/**
 * 
 */
module Sumof3arr {
}