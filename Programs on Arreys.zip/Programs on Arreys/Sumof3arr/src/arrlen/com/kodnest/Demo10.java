package arrlen.com.kodnest;

import java.util.Scanner;

public class Demo10 {

	public static void main(String[] args) {
Scanner scan=new Scanner(System.in);
System.out.println("Enter an arrey Length");
//int len=scan.nextInt();

int arr[]=new int[scan.nextInt()];

for(int i=0;i<=arr.length-1;i++) {
	System.out.println("enter an element");
	arr[i]=scan.nextInt();
}
	System.out.print("Arrey contents are.....");

	for(int i=0;i<=arr.length-1;i++) {
		System.out.print(arr[i]+" | ");
	}
	System.out.println();
}
	

}
